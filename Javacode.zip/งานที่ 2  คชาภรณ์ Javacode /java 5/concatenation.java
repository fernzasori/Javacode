package java5;

import java.util.Scanner;

public class concatenation {

	public static void main(String[] args) {
				Scanner kb = new Scanner(System.in);
				String out = "";
				while(true)
				{
					System.out.print(">>");
					String input = kb.nextLine();
					input = input.trim();
					out+=" "+input;
					if (input.equals(".")) break;
				}
				
				
				

			}


}
