package java5;

import java.util.Scanner;

public class wordextraction {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		System.out.print(">>");
		String input = kb.nextLine();
		String Line = kb.nextLine();
		Line = Line.trim();
		/*int i = 0;
		do {
			int j = i;
		
		while(!Line.substring(j, j+1).equals(" "))
			j++;
		{
			System.out.println("->"+Line.substring(i,j));
			i=j;
			
			
			input = input.trim();
			out+=" "+input;
			if (input.equals(".")) break;
		}*/

	}
}
	
