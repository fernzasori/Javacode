package java5;

import java.util.Scanner;

public class string3 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		System.out.print("ชื่อ  = ");
		int a = kb.nextInt();
		double d = kb.nextDouble();
		String n1 = kb.next();
		String n2 = kb.next();
		System.out.println(a);
		System.out.println(d);
		System.out.println("สวัสดีครับคุณ"+n1);
		System.out.println("สวัสดีครับคุณ"+n2);
	
	}

}
