package java7;

import java.util.Scanner;

public class Demoarray {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
		int n = 5;
		double[] data = new double[n];
		for (int i = 0;i < n;i++)
		{
			System.out.print("ข้อมูลตัวที่"+ (i+1)+"=");
			data[i] = kb.nextDouble(); 
		}
		double sum = 0;
		for(int i =0 ;i < n ; i++)
		{
			sum+=data[i];
		}
		double average = (sum/n);
		System.out.println("ค่าเฉลี่ย ="+ average);
		double[] v = new double[n];
		for(int i = 0;i<n ; i++)
		{
			v[i]= data[i] - average;
		}

}
}