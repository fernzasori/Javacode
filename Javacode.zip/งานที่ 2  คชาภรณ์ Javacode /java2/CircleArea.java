public class CirCleArea {
    public static void main(String[] args) {
        double r = 4.0;
        String msg = "พื้นที่วงกลมรัศมี ";
        double pi = 3.14;
        double area = pi * r * r;
        System.out.println(msg + r + " = " + area);
    }
}