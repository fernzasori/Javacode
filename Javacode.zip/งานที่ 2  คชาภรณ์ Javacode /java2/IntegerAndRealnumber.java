public class IntergerAndRealnumber {
    public static void main(String[] args) {
        System.out.println(5 / 2);
        System.out.println(5.0 / 2.0);
        System.out.println(5.0 / 2);
        System.out.println(5 / 2.0);
        System.out.println(5.25 / 0.5);

    }
}